# breaking-bad

## Getting started.

You need the following:

- Visual studuo code
- xammp with php

### Step 1
Open visual studio code and open the folder with the project.

### Step 2
Open a terminal in visual studio code and enter the following command:
```sh
php -S localhost:7777
```
This will run a local version of the site on port 7777

### Step 3
Open `localhost:7777` in your browser, enjoy!
