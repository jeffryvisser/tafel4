var modal = document.getElementById("myModal1");
var btn = document.getElementById("myBtn1");
var span = document.getElementsByClassName("close")[0];

btn.onclick = function () {
  modal.style.display = "block";
}

span.onclick = function () {
  modal.style.display = "none";
}

//modal2

var modal1 = document.getElementById("myModal2");
var btn1 = document.getElementById("myBtn2");
var span1 = document.getElementsByClassName("close")[1];

btn1.onclick = function () {
  modal1.style.display = "block";
}

span1.onclick = function () {
  modal1.style.display = "none";
}

//modal3

var modal3 = document.getElementById("myModal3");
var btn3 = document.getElementById("myBtn3");
var span3 = document.getElementsByClassName("close")[2];

btn3.onclick = function () {
  modal3.style.display = "block";
}

span3.onclick = function () {
  modal3.style.display = "none";
}

//modal4

var modal4 = document.getElementById("myModal4");
var btn4 = document.getElementById("myBtn4");
var span4 = document.getElementsByClassName("close")[3];

btn4.onclick = function () {
  modal4.style.display = "block";
}

span4.onclick = function () {
  modal4.style.display = "none";
}

//modal5

var modal5 = document.getElementById("myModal5");
var btn5 = document.getElementById("myBtn5");
var span5 = document.getElementsByClassName("close")[4];

btn5.onclick = function () {
  modal5.style.display = "block";
}

span5.onclick = function () {
  modal5.style.display = "none";
}

//modal6

var modal6 = document.getElementById("myModal6");
var btn6 = document.getElementById("myBtn6");
var span6 = document.getElementsByClassName("close")[5];

btn6.onclick = function () {
  modal6.style.display = "block";
}

span6.onclick = function () {
  modal6.style.display = "none";
}

//modal7

var modal7 = document.getElementById("myModal7");
var btn7 = document.getElementById("myBtn7");
var span7 = document.getElementsByClassName("close")[6];

btn7.onclick = function () {
  modal7.style.display = "block";
}

span7.onclick = function () {
  modal7.style.display = "none";
}

//modal8

var modal8 = document.getElementById("myModal8");
var btn8 = document.getElementById("myBtn8");
var span8 = document.getElementsByClassName("close")[7];

btn8.onclick = function () {
  modal8.style.display = "block";
}

span8.onclick = function () {
  modal8.style.display = "none";
}

//modal9

var modal9 = document.getElementById("myModal9");
var btn9 = document.getElementById("myBtn9");
var span9 = document.getElementsByClassName("close")[8];

btn9.onclick = function () {
  modal9.style.display = "block";
}

span9.onclick = function () {
  modal9.style.display = "none";
}

//modal10

var modal10 = document.getElementById("myModal10");
var btn10 = document.getElementById("myBtn10");
var span10 = document.getElementsByClassName("close")[9];

btn10.onclick = function () {
  modal10.style.display = "block";
}

span10.onclick = function () {
  modal10.style.display = "none";
}

//modal11

var modal11 = document.getElementById("myModal11");
var btn11 = document.getElementById("myBtn11");
var span11 = document.getElementsByClassName("close")[10];

btn11.onclick = function () {
  modal11.style.display = "block";
}

span11.onclick = function () {
  modal11.style.display = "none";
}

//modal12

var modal12 = document.getElementById("myModal12");
var btn12 = document.getElementById("myBtn12");
var span12 = document.getElementsByClassName("close")[11];

btn12.onclick = function () {
  modal12.style.display = "block";
}

span12.onclick = function () {
  modal12.style.display = "none";
}

window.onclick = function (event) {
  if (event.target == modal12) {
    modal12.style.display = "none";
  }
  if (event.target == modal11) {
    modal11.style.display = "none";
  }
  if (event.target == modal10) {
    modal10.style.display = "none";
  }
  if (event.target == modal9) {
    modal9.style.display = "none";
  }
  if (event.target == modal8) {
    modal8.style.display = "none";
  }
  if (event.target == modal7) {
    modal7.style.display = "none";
  }
  if (event.target == modal6) {
    modal6.style.display = "none";
  }
  if (event.target == modal5) {
    modal5.style.display = "none";
  }
  if (event.target == modal4) {
    modal4.style.display = "none";
  }
  if (event.target == modal3) {
    modal3.style.display = "none";
  }
  if (event.target == modal1) {
    modal1.style.display = "none";
  }
  if (event.target == modal) {
    modal.style.display = "none";
  }
}